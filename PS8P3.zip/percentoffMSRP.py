Honda Accord == 0.10
Toyota Rav4	== 0.15
All electric vehicles == 0.30
All other vehicles == 0.05
