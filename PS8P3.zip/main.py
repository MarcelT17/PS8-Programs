def doorprice(model,MSRP):
  MSRP=0.0
  if model=='Honda Accord':
    MSRP=0.10
  elif model=='Toyota Rav4':
    MSRP=0.15
  elif model=='electric':
    MSRP=0.30
  else:
    MSRP=0.05
  doorprice=code*(1+MSRP)
  return nextcode
def main():
  choice=input("yes or no?:")
  while choice=="yes":
    lastname=input("Enter name:")
    model=input("Enter model(i.e honda.):")
    code=int(input("Enter code:"))
    nextmodelcode=int(doorprice(model,code))
    print("The Next model code will be :",nextmodelcode)
    choice=input("Yes or no:")
main()
