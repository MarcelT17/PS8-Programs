def ticket(milesfromdt):
  ticketprice=0
  if milesfromdt>=30:
    ticketprice=12
  elif milesfromdt>=20 and milesfromdt<30:
    ticketprice=10
  elif milesfromdt>=10 and milesfromdt<20:
    ticketprice=8
  else:
    ticketprice=5
  return ticketprice  
def main():
  sum=0
  choice=input("yes of no:")
  while choice=='yes':
    lastname=input("Enter your last name:")
    milesfromdt=int(input("Enter miles from downtown chicago:"))
    sum=sum+ticket(milesfromdt)
    choice=input("yes or no:")
  print("The sum of all tickets:",sum)
main()
