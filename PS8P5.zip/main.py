def Assessed(county,marketvalue):
    assessedvp=0.0
    if county=='Cook':
        assessedvp=0.90
    elif county=='DuPage':
        assessedvp=0.80
    elif county=='McHenry':
        assessedvp=0.75
    elif county=='Kane':
        assessedvp=0.60
    else:
        assessedvp=0.70
    return marketvalue*assessedvp
def main():
    sum_market_values=0.0
    sum_assessed_values=0.0
    choice=input("yes on no:")
    while choice=='yes':
        county=input("Enter county:")
        marketvalue=float(input("Market value of a home:"))
        assval=float(Assessed(county,marketvalue))
        sum_market_values+=marketvalue
        sum_assessed_values+=assval
        choice=input("yes or no:")
    print("Total sum of all market values:",sum_market_values)
    print("Total sum of all Assessed values:",sum_assessed_values)
main()
