Cook = 0.90
DuPage = 0.80
McHenry	= 0.75
Kane	= 0.60
All others	= 0.70
