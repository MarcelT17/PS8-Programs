
def Squarefoot(length,width,height):
    return ((2*length*width)+(2*length*height)+(2*width*height))
def main():
  choice=input("yes or no?:")
  while choice=="yes":
    length=float(input("Enter length of the room:"))
    width=float(input("Enter width of the room:"))
    height=float(input("Enter height of the room:"))
    sqft=Squarefoot(length,width,height)
    numberofgallons=sqft/50
    print(numberofgallons," gallons needed\n")
    choice=input("yes or no?:")
main()
