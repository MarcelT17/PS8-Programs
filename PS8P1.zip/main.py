def forecast(month,sales):
  forecastvalue=0.0
  if month=='Jan' or month=='Feb' or month=='Mar':
    forecastvalue=0.10
  elif month=='Apr' or month=='May' or month=='Jun':
    forecastvalue=0.15
  elif month=='Jul' or month=='Aug' or month=='Sep':
    forecastvalue=0.20
  elif month=='Oct' or month=='Nov' or month=='Dec':
    forecastvalue=0.25
  nextsales=sales*(1+forecastvalue)
  return nextsales
def main():
  choice=input("yes or no?:")
  while choice=="yes":
    lastname=input("Enter name:")
    month=input("Enter month(i.e Jan,Feb etc.):")
    sales=int(input("Enter sales:"))
    nextmonthsales=int(forecast(month,sales))
    print("The Next month sales will be :",nextmonthsales)
    choice=input("Yes or no:")
main()
